
# Cobertura de Testing - Tienda Innova

## Herramientas
- Jasmine (framework)
- Karma (test runner)
- ChromeHeadless (navegador)

## Archivos probados (ejemplos incluidos)
- src/shared/ContactForm.jsx
  - Renderizado de inputs
  - Validación de formulario al enviar vacío
- src/data/data.js
  - CRUD: getAllProducts, addProduct, deleteProduct

## Cobertura proponida
Se recomienda agregar pruebas adicionales para:
- Componentes que manipulan el DOM (Productos, Carrito)
- Simulación de eventos (clics, cambios de input)
- Mocks para llamadas externas (si se integra API externa)

