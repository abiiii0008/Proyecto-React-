# Pruebas unitarias - Tienda Innova

Se incluyen pruebas básicas con **Jasmine + Karma**. A continuación instrucciones para ejecutar las pruebas y generar reporte de cobertura.

## Instalación (desde la carpeta del proyecto)
Instala las dependencias de testing:
```
npm install --save-dev karma jasmine-core karma-jasmine karma-chrome-launcher karma-webpack webpack webpack-cli babel-loader @babel/core @babel/preset-env @babel/preset-react karma-sourcemap-loader karma-coverage
```

## Ejecutar pruebas
Añade en package.json un script:
```
"test:unit": "karma start --single-run"
```
Luego ejecuta:
```
npm run test:unit
```

El resultado generará un reporte HTML en `/coverage/index.html`.

## Notas sobre alcance
- Se incluyen pruebas unitarias para `src/utils/fakeDB.js` (create, read, update, session).
- Recomendación: para cubrir componentes React (Login/Register), usar `@testing-library/react` y `jest` o adaptar Karma con `jsdom` y herramientas de renderizado.
