# ERS V2 - Tienda Innova

**Proyecto:** Tienda Innova  
**Autores:** Abihail Barría, Gerardo Vera

## 1. Introducción
Este documento ERS (Especificación de Requisitos del Software) versión V2 describe los requerimientos funcionales y no funcionales para la aplicación frontend "Tienda Innova" implementada en React.

## 2. Alcance
La aplicación permite navegar productos, registrarse, iniciar sesión, gestionar un carrito y realizar un checkout simulado. La persistencia de usuarios y sesión se realiza en `localStorage`.

## 3. Requerimientos funcionales
- RF1: El sistema debe permitir registrar usuarios (nombre, email, contraseña, dirección opcional).
- RF2: El sistema debe permitir iniciar sesión con email y contraseña.
- RF3: El sistema debe guardar sesión hasta que el usuario cierre sesión.
- RF4: El checkout debe autocompletar datos si el usuario está activo.
- RF5: Las rutas sensibles (checkout) deben estar protegidas.
- RF6: CRUD básico de usuarios (create, read, update) a través de `src/utils/fakeDB.js`.

## 4. Requerimientos no funcionales
- RNF1: Usar React (Create React App) y Bootstrap para diseño responsivo.
- RNF2: Tema visual gamer (azul oscuro, morado, neón).
- RNF3: Pruebas unitarias con Jasmine y Karma; cobertura mínima objetivo: 60% para los componentes clave.
- RNF4: Documentación ERS y documento de cobertura.

## 5. Casos de uso (resumidos)
- CU1: Registrar nuevo usuario.
- CU2: Iniciar sesión.
- CU3: Acceder a checkout protegido.
- CU4: Actualizar perfil (dirección).

## 6. Datos (modelo simplificado)
- Usuario: { id, name, email, passwordHash, address: { fullAddress } }

## 7. Entregables
- Código fuente en React.
- Pruebas unitarias (Jasmine + Karma).
- Documentación ERS y documento de cobertura.
