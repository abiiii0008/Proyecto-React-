// src/pages/Register.jsx
import React,{useState} from 'react'; 
import { useAuth } from '../context/AuthContext'; 
import { useNavigate } from 'react-router-dom'; 
// Importamos el Footer
import Footer from "../components/Footer"; 

export default function Register(){ 
    const {register}=useAuth(); 
    const navigate=useNavigate(); 
    const [form,setForm]=useState({name:'',email:'',password:'',password2:'',address:''}); 
    const [err,setErr]=useState(null); 
    const [sub,setSub]=useState(false); 
    
    function onChange(e){ 
        setForm(p=>({...p,[e.target.name]:e.target.value})); 
    } 
    
    async function onSubmit(e){ 
        e.preventDefault(); 
        setErr(null); 
        if(!form.name||!form.email||!form.password){ 
            setErr('Completa los campos'); 
            return;
        } 
        if(form.password!==form.password2){ 
            setErr('Las contraseñas no coinciden'); 
            return;
        } 
        setSub(true); 
        try{ 
            await register({name:form.name,email:form.email,password:form.password,address:{fullAddress:form.address}}); 
            navigate('/'); 
        }catch(err){ 
            setErr(err.message||'Error'); 
        } finally{ 
            setSub(false); 
        } 
    } 
    
    return (
        <>
            <div className='container mt-5'>
                <h2 className='text-neon'>Registro</h2>
                <form onSubmit={onSubmit} style={{maxWidth:600}}>
                    {err && <div className='alert alert-danger'>{err}</div>}
                    <div className='mb-3'>
                        <label className='form-label'>Nombre</label>
                        <input name='name' className='form-control' value={form.name} onChange={onChange} required/>
                    </div>
                    <div className='mb-3'>
                        <label className='form-label'>Email</label>
                        <input name='email' type='email' className='form-control' value={form.email} onChange={onChange} required/>
                    </div>
                    <div className='mb-3'>
                        <label className='form-label'>Contraseña</label>
                        <input name='password' type='password' className='form-control' value={form.password} onChange={onChange} required/>
                    </div>
                    <div className='mb-3'>
                        <label className='form-label'>Repetir Contraseña</label>
                        <input name='password2' type='password' className='form-control' value={form.password2} onChange={onChange} required/>
                    </div>
                    <div className='mb-3'>
                        <label className='form-label'>Dirección (opcional)</label>
                        <input name='address' className='form-control' value={form.address} onChange={onChange}/>
                    </div>
                    <button className='btn btn-primary' type='submit' disabled={sub}>
                        {sub? 'Registrando...':'Registrarse'}
                    </button>
                </form>
            </div>
            <Footer />
        </>
    ); 
}