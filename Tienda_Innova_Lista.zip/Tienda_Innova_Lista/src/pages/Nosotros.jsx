// src/pages/Nosotros.jsx
import React from "react";
// Importamos el Footer
import Footer from "../components/Footer"; 

export default function Nosotros() {
  return (
    <>
      <div className="container mt-4">
        <h2 className="text-neon">Nosotros</h2>
        <p>Tienda Innova es un proyecto demo para la Evaluación. Nuestra misión es entregar productos tecnológicos con una experiencia moderna y segura para el usuario.</p>
        <h4>Misión</h4>
        <p>Entregar tecnología accesible y experiencias memorables a los usuarios.</p>
        <h4>Visión</h4>
        <p>Ser referentes en innovación y diseño de tiendas online educativas.</p>
      </div>
      <Footer />
    </>
  );
}