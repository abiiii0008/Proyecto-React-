// src/pages/Contacto.jsx
import React, { useState } from "react";
// Importamos el componente Footer
import Footer from "../components/Footer"; 

export default function Contacto() {
  const [form, setForm] = useState({ name:'', email:'', message:'' });
  const [sent, setSent] = useState(false);
  function onChange(e){ setForm(p=>({...p, [e.target.name]: e.target.value})); }
  function onSubmit(e){ e.preventDefault(); if(!form.name||!form.email||!form.message){ alert('Completa los campos'); return; } setSent(true); setTimeout(()=> setSent(false), 3000); alert('Mensaje enviado (simulado)'); setForm({name:'',email:'',message:''}); }
  return (
    // Usamos un Fragmento para envolver el contenido y el Footer
    <>
      <div className="container mt-4">
        <h2 className="text-neon">Contacto</h2>
        <form onSubmit={onSubmit} style={{maxWidth:600}}>
          <div className="mb-3">
            <label className="form-label">Nombre</label>
            <input name="name" className="form-control" value={form.name} onChange={onChange} required/>
          </div>
          <div className="mb-3">
            <label className="form-label">Email</label>
            <input name="email" type="email" className="form-control" value={form.email} onChange={onChange} required/>
          </div>
          <div className="mb-3">
            <label className="form-label">Mensaje</label>
            <textarea name="message" className="form-control" value={form.message} onChange={onChange} required/>
          </div>
          <button className="btn btn-primary" type="submit">Enviar mensaje</button>
          {sent && <div className="mt-2 alert alert-success">Mensaje enviado (simulado)</div>}
        </form>
      </div>
      <Footer />
    </>
  );
}