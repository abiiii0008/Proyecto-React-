// src/pages/Blogs.jsx
import React from "react";
// Importamos el componente Footer
import Footer from "../components/Footer"; 

// Datos simulados para las publicaciones
const posts = [
  { id: 1, title: 'Las 5 tendencias tech de 2025', summary: 'Un resumen de lo que dominará el mundo tecnológico el próximo año.', date: '01/Oct/2025' },
  { id: 2, title: 'Guía para elegir tu primer mouse gaming', summary: 'Todo lo que necesitas saber sobre DPI, peso y ergonomía.', date: '15/Sep/2025' },
  { id: 3, title: 'Optimiza tu setup: Cables y organización', summary: 'Consejos prácticos para tener un escritorio limpio y eficiente.', date: '28/Ago/2025' },
];

export default function Blogs() {
  return (
    <>
      <div className="container mt-4">
        <h2 className="text-neon mb-4">Blog de Tienda Innova</h2>
        
        {posts.map(post => (
          <div key={post.id} className="card mb-3 shadow-sm">
            <div className="card-body">
              <h5 className="card-title text-neon">{post.title}</h5>
              <p className="card-text">{post.summary}</p>
              <p className="card-subtitle text-muted mb-2"><small>Publicado: {post.date}</small></p>
              {/* Aquí se podría usar Link de react-router-dom para ver el post completo */}
              <a href={`/blog/${post.id}`} className="btn btn-sm btn-outline-primary">Leer más</a>
            </div>
          </div>
        ))}

        {posts.length === 0 && (
          <div className="alert alert-info">No hay publicaciones de blog disponibles en este momento.</div>
        )}
      </div>
      
      {/* Integración del Footer */}
      <Footer />
    </>
  );
}