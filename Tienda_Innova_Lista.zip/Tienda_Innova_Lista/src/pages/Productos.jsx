// src/pages/Productos.jsx
import React from "react";
import { getAllProducts } from "../utils/products";
import { useCart } from "../context/CartContext";
import Footer from "../components/Footer"; 

export default function Productos() {
    // 1. Obtener los productos
    const allProducts = getAllProducts();
    
   
    const sortedProducts = allProducts.slice().sort((a, b) => {
        
        return a.name.localeCompare(b.name);
    });

    const { addToCart } = useCart();

    return (
        <>
            <div className="container mt-4">
                <h2 className="text-neon">Productos</h2>
                <div className="row">
                    {/* 3. Mapear la lista ORDENADA */}
                    {sortedProducts.map(p => (
                        <div key={p.id} className="col-md-6 col-lg-4 mb-3">
                            <div className="card h-100">
                                <img src={p.image} className="card-img-top" alt={p.name} style={{height:180, objectFit:'cover'}}/>
                                <div className="card-body">
                                    <h5 className="card-title text-neon">{p.name}</h5>
                                    <p className="card-text">{p.description}</p>
                                    <div className="d-flex justify-content-between align-items-center">
                                        <strong>${(p.price).toLocaleString('es-CL')}</strong>
                                        <button className="btn btn-primary btn-sm" onClick={() => addToCart(p, 1)}>Agregar al carrito</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            <Footer />
        </>
    );
}