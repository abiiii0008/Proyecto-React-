// src/context/CartContext.jsx
import React, { createContext, useContext, useEffect, useState } from "react";
import { getCartRaw, addToCart as addToCartStorage, removeFromCart as removeFromCartStorage, updateQuantity as updateQuantityStorage, clearCart as clearCartStorage, getCartCount as getCartCountStorage, getCartTotal as getCartTotalStorage } from "../utils/cartStorage";

const CartContext = createContext();
export function useCart() { return useContext(CartContext); }

export function CartProvider({ children }) {
  const [cart, setCart] = useState([]);
  const [count, setCount] = useState(0);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    const c = getCartRaw();
    setCart(c);
    setCount(getCartCountStorage());
    setTotal(getCartTotalStorage());
  }, []);

  function addToCart(product, quantity = 1) {
    const updated = addToCartStorage(product, quantity);
    setCart(updated);
    setCount(getCartCountStorage());
    setTotal(getCartTotalStorage());
  }

  function removeFromCart(productId) {
    const updated = removeFromCartStorage(productId);
    setCart(updated);
    setCount(getCartCountStorage());
    setTotal(getCartTotalStorage());
  }

  function updateQuantity(productId, quantity) {
    const updated = updateQuantityStorage(productId, quantity);
    setCart(updated);
    setCount(getCartCountStorage());
    setTotal(getCartTotalStorage());
  }

  function clearCart() {
    clearCartStorage();
    setCart([]);
    setCount(0);
    setTotal(0);
  }

  const value = { cart, count, total, addToCart, removeFromCart, updateQuantity, clearCart };
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
