
const STORAGE_KEY = "miTienda:products";

const initialProducts = [
  { id: 1, title: "Producto A", price: 19900, category: "Ofertas", stock: 10, description: "Descripción A" },
  { id: 2, title: "Producto B", price: 29900, category: "Electrónica", stock: 5, description: "Descripción B" },
  { id: 3, title: "Producto C", price: 15900, category: "Ofertas", stock: 8, description: "Descripción C" }
];

function load(){
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if(!raw){
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initialProducts));
      return [...initialProducts];
    }
    return JSON.parse(raw);
  } catch(e){
    console.error('Error leyendo productos', e);
    return [...initialProducts];
  }
}

function persist(list){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

export function getAllProducts(){
  return load();
}

export function getProductById(id){
  return load().find(p=>p.id===id);
}

export function addProduct(prod){
  const list = load();
  const id = list.length ? Math.max(...list.map(p=>p.id)) + 1 : 1;
  const newP = { id, ...prod };
  list.push(newP);
  persist(list);
  return newP;
}

export function updateProduct(id, changes){
  const list = load();
  const idx = list.findIndex(p=>p.id===id);
  if(idx===-1) return null;
  list[idx] = { ...list[idx], ...changes };
  persist(list);
  return list[idx];
}

export function deleteProduct(id){
  const list = load().filter(p=>p.id!==id);
  persist(list);
  return true;
}
