// src/utils/cartStorage.js - cart handling in localStorage
const CART_KEY = "tiendainnova_cart";

export function getCartRaw() {
  const raw = localStorage.getItem(CART_KEY);
  return raw ? JSON.parse(raw) : [];
}

export function saveCartRaw(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

export function addToCart(product, quantity = 1) {
  const cart = getCartRaw();
  const idx = cart.findIndex(i => i.id === product.id);
  if (idx === -1) {
    cart.push({ ...product, quantity });
  } else {
    cart[idx].quantity += quantity;
  }
  saveCartRaw(cart);
  return cart;
}

export function removeFromCart(productId) {
  let cart = getCartRaw();
  cart = cart.filter(i => i.id !== productId);
  saveCartRaw(cart);
  return cart;
}

export function updateQuantity(productId, quantity) {
  const cart = getCartRaw();
  const idx = cart.findIndex(i => i.id === productId);
  if (idx !== -1) {
    cart[idx].quantity = Math.max(1, quantity);
    saveCartRaw(cart);
  }
  return getCartRaw();
}

export function clearCart() {
  localStorage.removeItem(CART_KEY);
}

export function getCartCount() {
  const cart = getCartRaw();
  return cart.reduce((s, it) => s + (it.quantity || 1), 0);
}

export function getCartTotal() {
  const cart = getCartRaw();
  return cart.reduce((s, it) => s + (it.price * (it.quantity || 1)), 0);
}
