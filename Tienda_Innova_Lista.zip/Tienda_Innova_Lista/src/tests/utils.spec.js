import * as db from '../utils/fakeDB';

describe('utils module', () => {
  beforeEach(() => localStorage.clear());
  it('getAllUsers initially empty', () => {
    const users = db.getAllUsers();
    expect(Array.isArray(users)).toBeTrue();
    expect(users.length).toBe(0);
  });
});
