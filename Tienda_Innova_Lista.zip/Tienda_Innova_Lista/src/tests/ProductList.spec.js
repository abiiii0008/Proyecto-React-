
import { getAllProducts, addProduct, deleteProduct } from '../data/data';

describe('data CRUD', () => {
  it('returns products array', () => {
    const p = getAllProducts();
    expect(Array.isArray(p)).toBeTrue ? expect(Array.isArray(p)).toBeTrue() : expect(Array.isArray(p)).toBeTruthy();
  });

  it('adds and removes product', () => {
    const before = getAllProducts().length;
    const added = addProduct({ title:'Test', price:100, category:'Test', stock:1, description:'x' });
    expect(added.id).toBeGreaterThan(0);
    deleteProduct(added.id);
    const after = getAllProducts().length;
    expect(after).toBe(before);
  });
});
