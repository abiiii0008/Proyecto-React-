
import React, { useState } from "react";

export default function ContactForm(){
  const [form, setForm] = useState({ name:'', email:'', message:'' });
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState('');

  function validate(){
    const e = {};
    if(!form.name.trim()) e.name = 'Nombre requerido';
    if(!/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Email inválido';
    if(!form.message.trim()) e.message = 'Mensaje requerido';
    return e;
  }

  function handleChange(e){ setForm({...form, [e.target.name]: e.target.value}); }

  function handleSubmit(e){
    e.preventDefault();
    const v = validate();
    setErrors(v);
    if(Object.keys(v).length===0){
      setSuccess('Mensaje enviado. Gracias!');
      setForm({ name:'', email:'', message:'' });
      setTimeout(()=> setSuccess(''), 3000);
    }
  }

  return (
    <form onSubmit={handleSubmit} data-testid="contact-form">
      <div className="mb-3">
        <label>Nombre</label>
        <input name="name" value={form.name} onChange={handleChange} className="form-control" />
        {errors.name && <div className="text-danger small">{errors.name}</div>}
      </div>
      <div className="mb-3">
        <label>Correo</label>
        <input name="email" value={form.email} onChange={handleChange} className="form-control" />
        {errors.email && <div className="text-danger small">{errors.email}</div>}
      </div>
      <div className="mb-3">
        <label>Mensaje</label>
        <textarea name="message" value={form.message} onChange={handleChange} className="form-control"></textarea>
        {errors.message && <div className="text-danger small">{errors.message}</div>}
      </div>
      <button className="btn btn-primary" type="submit">Enviar Mensaje</button>
      {success && <div className="alert alert-success mt-2">{success}</div>}
    </form>
  );
}
